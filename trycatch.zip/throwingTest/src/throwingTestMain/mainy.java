package throwingTestMain;
public class mainy {
	public static void main(String... args) {
		try{
            time time = new time(13,31,369);
            time.printTime();
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
        finally {
            System.out.println("done");
        }
	}
}