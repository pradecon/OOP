package throwingTestMain;

class time {
	private int hour, min, sec;
	time(int hour,int minute,int second){
		setHour(hour);
		setMinute(minute);
		setSecond(second);
	}
	void setHour(int hour) {
		if(hour<0||hour>23)
			throw new IllegalArgumentException("wrong format for \"hour\"");
		this.hour=hour;
	}
	void setMinute(int min) {
		if(min<0||min>59)
			throw new IllegalArgumentException("wrong format for \"minute\"");
		this.min=min;
	}
	void setSecond(int sec) {
		if(sec<0||sec>59)
			throw new IllegalArgumentException("wrong format for \"second\"");
		this.sec=sec;
	}
	void printTime() {
		System.out.printf("%d:%d:%d\n",hour,min,sec);
	}
}
