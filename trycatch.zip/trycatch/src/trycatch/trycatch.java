package trycatch;

public class trycatch {
	public static void main(String... args) {
		try {
			System.out.println(1/0);
		}
		catch(Exception e) {
			System.out.println("Eror is: "+e.getMessage());
		}
		finally {
			System.out.println("Try block tried");
		}
	}

}
