import Enterprise.Company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the Company name: ");
        Company test = new Company(1234, scanner.next());
        System.out.print("Enter engineer(s) number that you want to add: ");
        for (byte n = scanner.nextByte(); n > 0; n--) {
            System.out.print("Enter the name of engineer: ");
            String name = scanner.next();
            System.out.print("Enter the id of engineer: ");
            int id = scanner.nextInt();
            test.addEngineers(id, name);
        }
        System.out.print("\nThe Company name is: "+test.getName());
        System.out.print("\n\nEnter the new name of Company: ");
        test.setName(scanner.next());
        System.out.println("\nThe new Company name is: "+test.getName());
        System.out.print("\nEnter the second new name of Company: ");
        test.setName(scanner.next());
        System.out.println("\nList of the Engineers");
        test.printEngineersDetails();

    }
}