package Enterprise;

public class Company {
    //Attributes
    private int taxNumber=0;
    private String name = new String();
    boolean check = true;

    //Constructor
    public Company(int taxNumber,String name){
        this.taxNumber=taxNumber;
        this.name=name;
    }

    //Behaviours
    public void setName(String name){
        if(check==true){
            this.name=name;
            check=false;
        }else{
            System.out.println("\nYou can not change name more than ones!\n\nCompany name is: ****"+this.name+"****");
        }
    }
    public String getName(){
        return name;
    }
    Engineers[] engineers = new Engineers[30];
    byte engineerCount = 0;
    public void addEngineers(int id,String name) {
        engineers[engineerCount] = new Engineers(id, name);
        engineerCount++;
    }
    public void printEngineersDetails(){
        byte tempCounter=1;
        for(Engineers test : engineers){
            if(test==null){
                break;
            }
            System.out.println(tempCounter+"- Id: "+test.getId()+" Name: "+test.getName());
            tempCounter++;
        }
    }
}