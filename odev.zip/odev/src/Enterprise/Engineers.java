package Enterprise;

class Engineers {
    //Attributes
    private int id=0;
    private String name = new String();
    //Constructor
    Engineers(int id,String name){
        this.id=id;
        this.name=name;
    }
    //Behaviours
    String getName(){
        return name;
    }
    int getId(){
        return id;
    }
}
